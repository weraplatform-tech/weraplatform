import { Request, Response, Router } from 'express';
import { supabaseAdmin } from '../lib/supabase';
import { AuthRequest } from '../middleware/auth';

export const notificationsRouter = Router();

notificationsRouter.get('/', async (req: AuthRequest, res: Response) => {
  const { data } = await supabaseAdmin
    .from('notifications')
    .select('*')
    .eq('user_id', req.user!.id)
    .order('created_at', { ascending: false })
    .limit(50);
  return res.json(data || []);
});

notificationsRouter.patch('/read-all', async (req: AuthRequest, res: Response) => {
  await supabaseAdmin
    .from('notifications').update({ is_read: true }).eq('user_id', req.user!.id);
  return res.json({ message: 'All notifications marked as read' });
});

notificationsRouter.patch('/:id/read', async (req: AuthRequest, res: Response) => {
  await supabaseAdmin
    .from('notifications').update({ is_read: true })
    .eq('id', req.params.id).eq('user_id', req.user!.id);
  return res.json({ message: 'Notification marked as read' });
});