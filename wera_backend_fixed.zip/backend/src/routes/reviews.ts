import { Request, Response, Router } from 'express';
import { supabaseAdmin } from '../lib/supabase';

export const reviewsRouter = Router();

reviewsRouter.get('/provider/:provider_user_id', async (req: Request, res: Response) => {
  const { data, error } = await supabaseAdmin
    .from('reviews')
    .select(`*, profiles!reviewer_id(first_name, last_name, avatar_url)`)
    .eq('reviewee_id', req.params.provider_user_id)
    .eq('is_public', true)
    .order('created_at', { ascending: false })
    .limit(20);

  if (error) return res.status(500).json({ error: 'Failed to fetch reviews' });
  return res.json(data);
});