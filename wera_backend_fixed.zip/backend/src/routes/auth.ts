import { Request, Response, Router } from 'express';
import { body, validationResult } from 'express-validator';
import { supabaseAdmin } from '../lib/supabase';

export const authRouter = Router();

// ── Register ──────────────────────────────────────────────────
authRouter.post('/register', [
  body('email').isEmail().normalizeEmail(),
  body('password').isLength({ min: 8 }),
  body('first_name').trim().isLength({ min: 2 }),
  body('last_name').trim().isLength({ min: 2 }),
  body('phone').matches(/^(\+254|0)[7][0-9]{8}$/),
  body('role').isIn(['client', 'provider']),
], async (req: Request, res: Response) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { email, password, first_name, last_name, phone, role } = req.body;

  try {
    const { data: authData, error: authError } = await supabaseAdmin.auth.admin.createUser({
      email, password,
      email_confirm: false,
      user_metadata: { first_name, last_name, role },
    });

    if (authError) return res.status(400).json({ error: authError.message });

    const { error: profileError } = await supabaseAdmin.from('profiles').insert({
      id: authData.user.id,
      first_name, last_name, phone, role,
      status: 'pending',
    });

    if (profileError) {
      await supabaseAdmin.auth.admin.deleteUser(authData.user.id);
      return res.status(500).json({ error: 'Failed to create profile' });
    }

    return res.status(201).json({
      message: 'Account created. Please verify your email.',
      user_id: authData.user.id,
    });
  } catch (err) {
    return res.status(500).json({ error: 'Registration failed' });
  }
});

// ── Login ─────────────────────────────────────────────────────
authRouter.post('/login', [
  body('email').isEmail().normalizeEmail(),
  body('password').notEmpty(),
], async (req: Request, res: Response) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { email, password } = req.body;

  try {
    const { data, error } = await supabaseAdmin.auth.signInWithPassword({ email, password });
    if (error) return res.status(401).json({ error: 'Invalid credentials' });

    const { data: profile } = await supabaseAdmin
      .from('profiles')
      .select('*, provider_profiles(*)')
      .eq('id', data.user.id)
      .single();

    // Update last_active
    await supabaseAdmin.from('profiles').update({ last_active: new Date().toISOString() }).eq('id', data.user.id);

    return res.json({
      access_token: data.session.access_token,
      refresh_token: data.session.refresh_token,
      expires_at: data.session.expires_at,
      user: profile,
    });
  } catch {
    return res.status(500).json({ error: 'Login failed' });
  }
});

// ── Refresh token ─────────────────────────────────────────────
authRouter.post('/refresh', async (req: Request, res: Response) => {
  const { refresh_token } = req.body;
  if (!refresh_token) return res.status(400).json({ error: 'Refresh token required' });

  try {
    const { data, error } = await supabaseAdmin.auth.refreshSession({ refresh_token });
    if (error) return res.status(401).json({ error: 'Invalid refresh token' });

    return res.json({
      access_token: data.session!.access_token,
      refresh_token: data.session!.refresh_token,
      expires_at: data.session!.expires_at,
    });
  } catch {
    return res.status(500).json({ error: 'Token refresh failed' });
  }
});

// ── Password reset ────────────────────────────────────────────
authRouter.post('/forgot-password', [
  body('email').isEmail().normalizeEmail(),
], async (req: Request, res: Response) => {
  const { email } = req.body;
  await supabaseAdmin.auth.admin.generateLink({
    type: 'recovery',
    email,
    options: { redirectTo: `${process.env.FRONTEND_URL}/auth/reset-password` },
  });
  // Always return 200 (don't reveal if email exists)
  return res.json({ message: 'If an account exists, a reset link has been sent.' });
});

// ── Profile ───────────────────────────────────────────────────
authRouter.get('/me', async (req: Request, res: Response) => {
  const token = req.headers.authorization?.slice(7);
  if (!token) return res.status(401).json({ error: 'Unauthorized' });

  try {
    const { data: { user } } = await supabaseAdmin.auth.getUser(token);
    if (!user) return res.status(401).json({ error: 'Unauthorized' });

    const { data: profile } = await supabaseAdmin
      .from('profiles')
      .select('*, provider_profiles(*), wallets(balance_kes, pending_kes)')
      .eq('id', user.id)
      .single();

    return res.json(profile);
  } catch {
    return res.status(500).json({ error: 'Failed to fetch profile' });
  }
});