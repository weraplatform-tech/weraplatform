import { Request, Response, Router } from 'express';
import { supabaseAdmin } from '../lib/supabase';
import { requireRole } from '../middleware/auth';

export const adminRouter = Router();
adminRouter.use(requireRole('admin', 'super_admin'));

adminRouter.get('/stats', async (_req: Request, res: Response) => {
  const [users, providers, bookings, payments] = await Promise.all([
    supabaseAdmin.from('profiles').select('id', { count: 'exact', head: true }),
    supabaseAdmin.from('provider_profiles').select('id', { count: 'exact', head: true }),
    supabaseAdmin.from('bookings').select('id', { count: 'exact', head: true }),
    supabaseAdmin.from('payments').select('amount_kes').eq('status', 'completed'),
  ]);

  const totalRevenue = payments.data?.reduce((sum: number, p: any) => sum + parseFloat(p.amount_kes), 0) || 0;

  return res.json({
    total_users: users.count || 0,
    total_providers: providers.count || 0,
    total_bookings: bookings.count || 0,
    total_gmv_kes: totalRevenue,
    platform_revenue_kes: totalRevenue * 0.15,
    currency: 'KES',
  });
});

adminRouter.get('/users', async (req: Request, res: Response) => {
  const { page = '1', limit = '50', role, status } = req.query as Record<string, string>;
  let query = supabaseAdmin.from('profiles').select('*', { count: 'exact' });
  if (role) query = query.eq('role', role);
  if (status) query = query.eq('status', status);
  query = query
    .order('created_at', { ascending: false })
    .range((parseInt(page) - 1) * parseInt(limit), parseInt(page) * parseInt(limit) - 1);
  const { data, count } = await query;
  return res.json({ users: data, total: count });
});

adminRouter.patch('/users/:id/status', async (req: Request, res: Response) => {
  const { status } = req.body;
  const { data, error } = await supabaseAdmin
    .from('profiles').update({ status }).eq('id', req.params.id).select().single();
  if (error) return res.status(500).json({ error: 'Failed to update user status' });
  return res.json(data);
});