import { Request, Response, Router } from 'express';
import { supabaseAdmin } from '../lib/supabase';
import { authMiddleware, AuthRequest } from '../middleware/auth';

export const servicesRouter = Router();

servicesRouter.get('/', async (req: Request, res: Response) => {
  const { category, q, page = '1', limit = '24' } = req.query as Record<string, string>;
  const pageNum = parseInt(page);
  const limitNum = Math.min(50, parseInt(limit));

  let query = supabaseAdmin
    .from('services')
    .select(`
      id, title, description, category, price_kes, price_type,
      images, tags, views, bookings_count, is_featured,
      provider_profiles!inner(
        id, rating_avg, rating_count,
        profiles!inner(first_name, last_name, avatar_url, county)
      )
    `, { count: 'exact' })
    .eq('is_active', true);

  if (category) query = query.eq('category', category);
  if (q) query = query.textSearch('title', q);
  query = query
    .order('is_featured', { ascending: false })
    .order('bookings_count', { ascending: false })
    .range((pageNum - 1) * limitNum, pageNum * limitNum - 1);

  const { data, error, count } = await query;
  if (error) return res.status(500).json({ error: 'Failed to fetch services' });
  return res.json({ services: data, total: count });
});

servicesRouter.get('/:id', async (req: Request, res: Response) => {
  const { data, error } = await supabaseAdmin
    .from('services')
    .select(`*, provider_profiles(*, profiles(*))`)
    .eq('id', req.params.id)
    .single();

  if (error || !data) return res.status(404).json({ error: 'Service not found' });
  await supabaseAdmin.from('services').update({ views: (data.views || 0) + 1 }).eq('id', req.params.id);
  return res.json(data);
});

servicesRouter.post('/', authMiddleware, async (req: AuthRequest, res: Response) => {
  const userId = req.user!.id;
  const { data: pp } = await supabaseAdmin
    .from('provider_profiles').select('id').eq('user_id', userId).single();
  if (!pp) return res.status(400).json({ error: 'Provider profile required' });

  const { data, error } = await supabaseAdmin
    .from('services').insert({ ...req.body, provider_id: pp.id }).select().single();
  if (error) return res.status(500).json({ error: 'Failed to create service' });
  return res.status(201).json(data);
});